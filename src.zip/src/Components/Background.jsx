import React from "react";

const Background = () => {
  return (
    <div className="bg w-full h-full">
      <img src="/images/background.jpg" />
    </div>
  );
};

export default Background;
